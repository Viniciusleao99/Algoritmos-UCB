# Projeto_Algoritmo

### Projeto final para a disciplina de Algoritmo e programação

## Alunos:

#### Leonardo Ribeiro De Macedo - UC22200681 - Ciência da computação 
#### Maria Rafaela Alves Azevedo De Jesus - UC22200231 - Análise e desenvolvimento de sistemas
#### Vinicius Arantes Leão - UC22200223 - Ciência da computação
